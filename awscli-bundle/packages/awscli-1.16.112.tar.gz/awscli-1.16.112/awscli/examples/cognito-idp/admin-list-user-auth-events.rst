**To list authorization events for a user**

This example lists authorization events for username diego@example.com. 

Command::

  aws cognito-idp admin-list-user-auth-events --user-pool-id us-west-2_aaaaaaaaa --username diego@example.com
  
